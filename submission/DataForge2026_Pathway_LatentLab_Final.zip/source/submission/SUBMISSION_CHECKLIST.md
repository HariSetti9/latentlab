# DataForge Pathway Submission Checklist

| Requirement | Status | Evidence / required action |
|---|---|---|
| Narrow falsifiable claim | [PASS] | Charter, README, PDFs, live flow |
| Real recurrent fixed-size computation | [PASS] | Engine, tests, UI |
| Independent truth beside estimate | [PASS] | BFS module and live comparison |
| Honest limitation case | [PASS] | Saturation preset/report |
| Guided interactive learning flow | [PASS] | Hero, journey, sandbox, self-check |
| Substantive BDH/BDH-CQ module | [PASS] | In-flow comparison, citations, non-equivalence |
| At least 3 recent primary papers | [PASS] | Four papers from 2024-2026 |
| Deterministic evaluation/reproduction | [PASS] | 10 fixtures, 80 cases, `pnpm reproduce` |
| Complete README with deliverable links | [PASS] | Verified public app, repository, CI, video, and PDFs |
| One-page concept-summary source/PDF | [PASS] | `docs/CONCEPT_SUMMARY.md`, `docs/concept-summary.pdf` |
| Blog source/PDF | [PASS] | `docs/BLOG.md`, `docs/blog.pdf` |
| Provenance/licenses/AI disclosure | [PASS] | Dedicated records and MIT license |
| Desktop/mobile QA evidence | [PASS] | Curated deterministic screenshots and QA notes |
| Deployment and CI configuration | [PASS] | GitHub Actions workflow, configurable base path, and deployment runbook validated locally |
| Public artifact opens without sign-in | [PASS] | GitHub Pages root and deterministic fixtures verified publicly |
| Public source repository opens | [PASS] | Public `HariSetti9/latentlab` repository verified |
| Hosted CI | [PASS] | GitHub Actions final-closure run 34488924796 passed verification and deployment |
| Demo video opens | [PASS] | Public Drive viewer; release owner verified Incognito playback without sign-in |
| README has final public/video links | [PASS] | Verified repository, artifact, and video links inserted |
| Full external accessibility audit | [BLOCKED] | Internal semantic/keyboard/reflow audit passed; native screen-reader, Firefox, and Safari coverage is unavailable locally and remains documented residual risk |
| Strict release validation | [PASS] | Repository, artifact, hosted CI, and demo-video HTTPS fields are mandatory and validated |
| Final ZIP and SHA-256 | [PASS] | Deterministic final archive verified and checksum recorded in `FINAL_RELEASE.md` |
| Unstop upload and confirmed submission | [NEEDS USER ACTION] | Final remaining human action: upload the final ZIP, click Submit, and verify confirmation |

This file records current evidence, not planned work. A [PASS] item has an inspectable repository artifact now.
